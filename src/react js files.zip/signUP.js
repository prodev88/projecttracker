

import React from 'react';
import './signUP.css';


import { useNavigate} from "react-router-dom";

import { useState } from 'react';

 const Signup = () => {
  const [na, changena] = useState("");
  const [em, changeem] = useState("");
  const [pa, changepa] = useState("");

   let nav=useNavigate();
    
  
    
   function handlesubmit(e){
     if(na.length===0 || em.length===0 || pa.length===0)
     {
       alert("VALUE IS EMPTY ");
     }
     else
     {
    e.preventDefault();
    fetch("http://localhost:4000/postdata", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name:na,
        email:em,
        password:pa
      })
    })
      .then(res => {
        console.log("response: ", res);
      })
      .catch(err => {
        console.log("error:", err);
      });
      console.log(na+pa+em);
      nav('/new');
    }

  }
 function onname(e)
 {

  changena(e.target.value);
  
   
 }
 function onemail(e)
 {
  
  changeem(e.target.value);
  
 }
 function onpass(e)
 {
  changepa(e.target.value);
  
 }
  return(
    <div className="maindiv">
     
        
       
      <div className="box" >
      <h1> SIGN UP </h1>
    <form>
      
        
        <div className="grp"> 
          <label htmlFor="name">Name:</label>
          <input type="text" name="name" id="name" placeholder="Enter Name" onChange={onname}/> 
          </div>
          <div className="grp">
          <label htmlFor="email">Email:</label>
          <input type="email" name="email" id="email" placeholder="Enter Email" onChange={onemail} /> 
          </div>
          
          <div className="grp">
          <label htmlFor="password">Password:</label>
          <input type="password" name="password" id="password" placeholder="Enter Password" onChange={onpass}/> 
    
          </div>
           <input type="submit" value="SIGN UP" onClick={handlesubmit}></input>
      
    </form>
        

    </div>
    </div>
      );
}
export default Signup;
import React from 'react';
import './newpage.css';


function Newpage() {
    return (
        <div>
        
            <h1> second page</h1>
        </div>
    )
}

export default Newpage;

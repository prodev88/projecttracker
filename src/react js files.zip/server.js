  const express=require('express');
  const cors=require('cors');
  const app=express();
  const mongoose=require('mongoose');
  const bodyparser=require("body-parser");
  app.use(bodyparser.urlencoded({extended:true}));
  app.use(express.json())
  mongoose.connect("mongodb+srv://ram:ram123@project1.m3pbh.mongodb.net/prodb?retryWrites=true&w=majority",{ useNewUrlParser: true,
  useUnifiedTopology: true,});
app.use(
    cors(
        {
            origin:"http://localhost:3000"
        }
    )
)

  //schema

  const sch={
      name:String,
      email:String,
      password:String
  }
  const mod=mongoose.model("mod",sch);


//SIGN IN 
  app.post("/check",async(req,res)=>{
      const email=req.body.email;
      const password=req.body.password;
      console.log(req.body);
    const extr= await mod.findOne({email:email});
    //res.send(extr);
    //console.log(extr);
    if(extr && extr.password===password)
    {
        res.send("U R THERE");
    }else{
        res.send("wrong pass")
    }



  })

// push data
   app.post("/postdata",async(req,res)=>{
      
      console.log(req.body);
      try {
        const newmod= new mod(
            {
                name:req.body.name,email:req.body.email,password: req.body.password
            }
        );
        const a=await newmod.save();
        res.json(a);
          
      } catch (error) {
          console.log(error);
      }
  })
   

 

  app.listen(4000,()=>{
      console.log("on server 4000");
  })